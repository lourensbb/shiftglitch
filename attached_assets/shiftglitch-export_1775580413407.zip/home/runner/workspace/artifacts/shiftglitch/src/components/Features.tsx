const TOOLS = [
  {
    id: "01",
    name: "Learning Governor",
    codename: "POMODORO ENGINE",
    color: "#39FF14",
    science: "Pomodoro Technique + Deliberate Practice",
    desc: "25-minute focused sessions. Subject tagging. Phone-lock nudge. After 4 consecutive same-domain sessions, the Governor blocks you and forces a breakdown. Every session earns evidence toward rank.",
    badge: "FREE",
  },
  {
    id: "02",
    name: "Flashcard Decks",
    codename: "DATA SHARDS — LEITNER SYSTEM",
    color: "#39FF14",
    science: "Spaced Repetition — Leitner 5-Box Method",
    desc: "Not just flashcards. A full implementation of the Leitner System — cards sorted into 5 boxes by retention level. Visual orbit indicators show memory stability. Cards that advance through boxes count as rank evidence.",
    badge: "FREE",
  },
  {
    id: "03",
    name: "Blurting Method",
    codename: "BRAINDUMP PROTOCOL",
    color: "#FF00FF",
    science: "Active Recall — Testing Effect (Roediger & Karpicke, 2006)",
    desc: "4-phase guided active recall. Write everything you know from memory. Read your notes. Write again. Compare. Confront exactly what you do and don't know. The most honest study method available.",
    badge: "FREE",
  },
  {
    id: "04",
    name: "Boss Fights",
    codename: "MCQ DIAGNOSTIC MISSIONS",
    color: "#FF00FF",
    science: "Retrieval Practice — Forced Recall Under Pressure",
    desc: "100-question MCQ knowledge assessment across 5 missions. Every question tied to real learning science. Surfaces knowledge gaps directly. Each submission counts as rank evidence.",
    badge: "FREE",
  },
  {
    id: "05",
    name: "Babel Fish Lab",
    codename: "FEYNMAN TECHNIQUE MODULE",
    color: "#8A2BE2",
    science: "Feynman Technique — Explanation as Understanding Test",
    desc: "If you cannot explain it simply, you do not understand it. Choose a concept. Write a plain-language explanation as if teaching a 10-year-old. Add a rough sketch. The explanation reveals the gaps.",
    badge: "FREE",
  },
  {
    id: "06",
    name: "Escape Runs",
    codename: "REPEATABLE DOMAIN CLEARANCE",
    color: "#8A2BE2",
    science: "Spaced Practice + Interleaving + Metacognition",
    desc: "Name a knowledge domain. Run 6 ordered cognitive exploits in sequence. Achieve Domain Clearance. Reset and run again. The repeat mechanic is the point — second run is always deeper than the first.",
    badge: "FREE",
  },
  {
    id: "07",
    name: "System INTERRUPT",
    codename: "DYNAMIC EVENT ENGINE",
    color: "#FF8800",
    science: "Spaced Alerts — Forgetting Curve Enforcement",
    desc: "The Mainframe fights back. Full-screen dramatic events fire when decks decay (72h without review), when you go inactive (3+ days), when you earn a rank promotion. The app feels alive. The Mainframe feels hostile.",
    badge: "FREE",
  },
  {
    id: "08",
    name: "The Warden",
    codename: "ADVERSARIAL CHARACTER SYSTEM",
    color: "#FF8800",
    science: "Operant Conditioning + Narrative Engagement",
    desc: "47 messages. Three modes: observer, guide, adversary. The Warden appears unpredictably. Snakes and Ladders progression — streaks earn bonuses, inactivity earns penalties. Non-linear. Unpredictable. Real.",
    badge: "FREE",
  },
];

export default function Features() {
  return (
    <section id="features" className="py-24 sm:py-32 bg-black relative overflow-hidden">
      <div className="absolute right-0 top-0 bottom-0 w-1 bg-[#39FF14]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="sector-label mb-4">// COGNITIVE EXPLOIT MODULES — LOADED</div>

        <div className="mb-16">
          <h2 className="font-display text-5xl sm:text-6xl text-white mb-4 leading-tight">
            EIGHT TOOLS.
            <span className="text-[#39FF14] glow-green"> ALL GROUNDED IN</span>
            <span className="block">PEER-REVIEWED SCIENCE.</span>
          </h2>
          <p className="text-white/60 max-w-2xl font-mono-sg text-sm">
            Every tool is a structured implementation of a known learning method. Students are not just given a timer. They are given a framework.
          </p>
        </div>

        <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-4">
          {TOOLS.map((tool) => (
            <div
              key={tool.id}
              className="border border-white/10 p-5 bg-white/[0.02] hover:border-opacity-60 hover:bg-white/[0.04] transition-all group"
              style={{ "--hover-color": tool.color } as React.CSSProperties}
            >
              <div className="flex items-start justify-between mb-3">
                <span className="font-display text-3xl" style={{ color: tool.color }}>
                  {tool.id}
                </span>
                <span
                  className="font-mono-sg text-xs px-2 py-0.5 border"
                  style={{ borderColor: tool.color, color: tool.color }}
                >
                  {tool.badge}
                </span>
              </div>

              <div className="font-mono-sg text-xs tracking-widest mb-1" style={{ color: tool.color }}>
                {tool.codename}
              </div>
              <div className="font-display text-xl text-white mb-3">{tool.name}</div>

              <div className="font-mono-sg text-xs text-white/30 mb-3 pb-3 border-b border-white/10">
                SCIENCE: {tool.science}
              </div>

              <p className="text-white/60 text-xs leading-relaxed">{tool.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 text-center">
          <p className="font-mono-sg text-xs text-white/30 tracking-widest">
            + 10 COGNITIVE EXPLOIT MODULES · LEADERBOARD · SQUAD MODE · TEACHER DASHBOARD · ACHIEVEMENT BADGES
          </p>
        </div>
      </div>
    </section>
  );
}
