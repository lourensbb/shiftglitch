import { useRef, useState } from "react";
import brandVideo from "@assets/Cyberpunk_Logo_Reveal_ShiftGlitch_2_1775287889376.mp4";

export default function BrandVideo() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (playing) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setPlaying(!playing);
  };

  return (
    <section className="py-24 sm:py-32 bg-[#030303] relative overflow-hidden">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center">
        <div className="sector-label mb-4">// MAINFRAME TRANSMISSION INCOMING</div>

        <h2 className="font-display text-4xl sm:text-5xl text-white mb-4">
          THE STUDY APP THAT LOOKS LIKE IT BELONGS IN
          <span className="text-[#FF00FF] glow-magenta"> A HACKING MOVIE.</span>
        </h2>
        <p className="text-white/60 font-mono-sg text-sm mb-10 max-w-xl mx-auto">
          The cyberpunk angle is not decoration. It is deliberate. ShiftGlitch is competing on philosophy — not on features, not on UI trends.
        </p>

        <div className="relative group cursor-pointer" onClick={togglePlay}>
          <video
            ref={videoRef}
            src={brandVideo}
            muted
            loop
            playsInline
            onEnded={() => setPlaying(false)}
            className="w-full aspect-video object-cover"
          />

          {/* Play overlay */}
          {!playing && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/60 group-hover:bg-black/40 transition-colors">
              <div className="w-20 h-20 border-2 border-[#39FF14] flex items-center justify-center glow-green-box hover:bg-[#39FF14]/10 transition-colors">
                <div className="w-0 h-0 border-t-[12px] border-t-transparent border-b-[12px] border-b-transparent border-l-[20px] border-l-[#39FF14] ml-2" />
              </div>
            </div>
          )}

          {/* Scanlines */}
          <div className="absolute inset-0 scanlines opacity-20 pointer-events-none" />

          {/* Corner decorations */}
          <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-[#39FF14]" />
          <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-[#39FF14]" />
          <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-[#39FF14]" />
          <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-[#39FF14]" />

          {/* Status bar */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 font-mono-sg text-xs text-[#39FF14] tracking-widest">
            {playing ? "▶ MAINFRAME ACTIVE" : "▶ CLICK TO TRANSMIT"}
          </div>
        </div>
      </div>
    </section>
  );
}
