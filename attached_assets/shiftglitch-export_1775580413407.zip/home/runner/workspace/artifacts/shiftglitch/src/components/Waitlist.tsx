export default function Waitlist() {
  return (
    <section id="waitlist" className="py-24 sm:py-32 bg-black relative overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: "radial-gradient(ellipse 80% 60% at 50% 50%, rgba(57,255,20,0.06) 0%, transparent 70%)",
        }}
      />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 text-center relative z-10">
        <div className="sector-label mb-4">// MAINFRAME ACCESS — OPEN</div>

        <h2 className="font-display text-5xl sm:text-7xl text-white mb-4 leading-tight">
          READY TO
          <span className="text-[#39FF14] glow-green block">JACK IN?</span>
        </h2>

        <p className="text-white/70 leading-relaxed mb-3">
          The study methods OS for teenagers. Built on cognitive science, not the vibe. Free to start — no card required.
        </p>
        <p className="font-mono-sg text-sm text-[#39FF14] mb-10">
          The core tools are free. Always.
        </p>

        <div className="space-y-4">
          <a
            href="https://shiftglitch.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block font-mono-sg text-sm tracking-widest px-10 py-4 bg-[#39FF14] text-black font-bold hover:bg-white transition-colors uppercase pulse-green"
          >
            Jack In — It's Free
          </a>
          <p className="font-mono-sg text-xs text-white/30 block mt-3">
            No card required. Free tier is permanent.
          </p>
        </div>

        <div className="mt-16 grid sm:grid-cols-3 gap-6 border-t border-white/10 pt-12">
          {[
            { icon: "◈", label: "COGNITIVE SCIENCE", desc: "Every tool grounded in peer-reviewed research. No pseudoscience. No vibe-based claims." },
            { icon: "◉", label: "BEHAVIOUR REWARDED", desc: "Progression earned by demonstrated study behaviours — not by time on screen or purchases." },
            { icon: "✦", label: "HONEST BY DESIGN", desc: "The app surfaces gaps. It does not celebrate mediocre scores. Honesty is the mechanism." },
          ].map(({ icon, label, desc }) => (
            <div key={label} className="text-center">
              <div className="font-display text-4xl text-[#39FF14] glow-green mb-3">{icon}</div>
              <div className="font-mono-sg text-xs text-[#39FF14] tracking-widest mb-2">{label}</div>
              <p className="text-white/50 text-xs leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
