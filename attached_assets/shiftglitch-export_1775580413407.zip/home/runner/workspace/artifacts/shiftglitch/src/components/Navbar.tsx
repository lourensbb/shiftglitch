import { useState, useEffect } from "react";
import logoImg from "@assets/SHIFTGLITCH_logo_grades_and_aura_fall_up_left_1775287889377.png";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-black/95 border-b border-[#39FF14]/30 backdrop-blur-sm"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src={logoImg} alt="ShiftGlitch" className="h-10 w-auto" />
        </div>

        <div className="hidden md:flex items-center gap-8">
          {[
            ["the-problem", "The Problem"],
            ["features", "Tools"],
            ["ranks", "Ranks"],
            ["pricing", "Pricing"],
          ].map(([id, label]) => (
            <button
              key={id}
              onClick={() => scrollTo(id)}
              className="font-mono-sg text-xs tracking-widest text-white/60 hover:text-[#39FF14] transition-colors uppercase"
            >
              {label}
            </button>
          ))}
        </div>

        <a
          href="https://shiftglitch.com"
          target="_blank"
          rel="noopener noreferrer"
          className="font-mono-sg text-xs tracking-widest px-5 py-2 border border-[#39FF14] text-[#39FF14] hover:bg-[#39FF14] hover:text-black transition-all duration-200 uppercase"
        >
          Enter the Mainframe
        </a>
      </div>
    </nav>
  );
}
