const RANKS = [
  {
    icon: "◈",
    name: "NPC",
    tagline: "The system controls you.",
    color: "#ffffff",
    desc: "Starting rank. No evidence required. This is where everyone begins — being moved by systems they don't understand.",
    requirements: null,
  },
  {
    icon: "◉",
    name: "Script Kiddie",
    tagline: "You've learned some tricks.",
    color: "#39FF14",
    desc: "You've started using the tools. Consistency is forming. The Mainframe acknowledges your presence.",
    requirements: { pomodoros: 15, blurts: 10, breakdowns: 10, cards: 50, days: 7, diagnostics: 2 },
  },
  {
    icon: "⬡",
    name: "Glitch Tech",
    tagline: "You understand how the system works.",
    color: "#8A2BE2",
    desc: "Evidence of sustained practice. You are no longer just using the tools — you understand what they do and why.",
    requirements: { pomodoros: 40, blurts: 25, breakdowns: 20, cards: 120, days: 20, diagnostics: 5 },
  },
  {
    icon: "◬",
    name: "Netrunner",
    tagline: "Deep inside the system.",
    color: "#FF8800",
    desc: "Significant demonstrated behaviour. The Mainframe has noticed. Real mastery is taking shape — not claimed, proven.",
    requirements: { pomodoros: 80, blurts: 50, breakdowns: 40, cards: 250, days: 40, diagnostics: 10 },
  },
  {
    icon: "✦",
    name: "System Admin",
    tagline: "You own the Mainframe.",
    color: "#FF00FF",
    desc: "The highest rank. Earned by sustained, documented evidence of real learning behaviours across weeks and months. Permanent. Irreversible. Impossible to fake.",
    requirements: { pomodoros: 150, blurts: 100, breakdowns: 75, cards: 500, days: 75, diagnostics: 20 },
  },
];

const EvidenceBar = ({ label, value, max, color }: { label: string; value: number; max: number; color: string }) => (
  <div className="flex items-center gap-2 text-xs">
    <span className="font-mono-sg text-white/40 w-20 shrink-0">{label}</span>
    <div className="flex-1 h-1 bg-white/10">
      <div
        className="h-full transition-all"
        style={{ width: `${(value / max) * 100}%`, backgroundColor: color }}
      />
    </div>
    <span className="font-mono-sg text-white/40 w-8 text-right">{value}</span>
  </div>
);

export default function RankSystem() {
  const maxValues = { pomodoros: 150, blurts: 100, breakdowns: 75, cards: 500, days: 75, diagnostics: 20 };

  return (
    <section id="ranks" className="py-24 sm:py-32 bg-black relative overflow-hidden">
      <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#8A2BE2]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="sector-label mb-4">// RANK PROGRESSION MATRIX — EVIDENCE-BASED ONLY</div>

        <div className="mb-16">
          <h2 className="font-display text-5xl sm:text-6xl text-white mb-4 leading-tight">
            FIVE RANKS.
            <span className="text-[#8A2BE2] block">EARNED BY BEHAVIOUR.</span>
            NOT BY PURCHASES.
          </h2>
          <p className="text-white/60 font-mono-sg text-sm max-w-2xl">
            Progression is permanent and irreversible. It cannot be bought, skipped, or hacked. Every threshold must be met simultaneously. There are no shortcuts — except the legitimate ones.
          </p>
        </div>

        <div className="grid md:grid-cols-5 gap-4">
          {RANKS.map((rank, i) => (
            <div
              key={rank.name}
              className="border border-white/10 p-5 bg-white/[0.02] hover:bg-white/[0.04] transition-all flex flex-col"
              style={{ borderTopColor: rank.color, borderTopWidth: 2 }}
            >
              <div className="text-3xl mb-2" style={{ color: rank.color }}>
                {rank.icon}
              </div>
              <div className="font-mono-sg text-xs tracking-widest mb-1" style={{ color: rank.color }}>
                TIER 0{i}
              </div>
              <div className="font-display text-2xl text-white mb-1">{rank.name}</div>
              <div className="font-mono-sg text-xs text-white/40 italic mb-3">{rank.tagline}</div>
              <p className="text-white/60 text-xs leading-relaxed mb-4 flex-1">{rank.desc}</p>

              {rank.requirements && (
                <div className="space-y-1.5 border-t border-white/10 pt-4">
                  <EvidenceBar label="Pomodoros" value={rank.requirements.pomodoros} max={maxValues.pomodoros} color={rank.color} />
                  <EvidenceBar label="Blurts" value={rank.requirements.blurts} max={maxValues.blurts} color={rank.color} />
                  <EvidenceBar label="Breakdowns" value={rank.requirements.breakdowns} max={maxValues.breakdowns} color={rank.color} />
                  <EvidenceBar label="Cards" value={rank.requirements.cards} max={maxValues.cards} color={rank.color} />
                  <EvidenceBar label="Days" value={rank.requirements.days} max={maxValues.days} color={rank.color} />
                  <EvidenceBar label="Boss Fights" value={rank.requirements.diagnostics} max={maxValues.diagnostics} color={rank.color} />
                </div>
              )}
              {!rank.requirements && (
                <div className="border-t border-white/10 pt-4">
                  <p className="font-mono-sg text-xs text-white/30">No evidence required. This is where everyone begins.</p>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-10 grid sm:grid-cols-3 gap-4">
          {[
            { label: "CONSISTENCY LADDER BONUS", color: "#39FF14", desc: "7-day streak → 10% threshold reduction on all rank requirements." },
            { label: "CLEARANCE STRIP PENALTY", color: "#FF00FF", desc: "10+ day inactivity → rank promotion blocked until activity resumes." },
            { label: "PERFORMANCE SHORTCUT", color: "#FF8800", desc: "BrainDump 200+ words + Boss Fight 90%+ + Speed Run 5/5 → immediate clearance boost." },
          ].map(({ label, color, desc }) => (
            <div key={label} className="border border-white/10 p-4 bg-white/[0.02]">
              <div className="font-mono-sg text-xs tracking-widest mb-2" style={{ color }}>
                {label}
              </div>
              <p className="text-white/60 text-xs leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
