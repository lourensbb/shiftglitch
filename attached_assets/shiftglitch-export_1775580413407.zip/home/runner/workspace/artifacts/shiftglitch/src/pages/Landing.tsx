import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Problem from "@/components/Problem";
import WhatItIs from "@/components/WhatItIs";
import Features from "@/components/Features";
import BrandVideo from "@/components/BrandVideo";
import RankSystem from "@/components/RankSystem";
import Pricing from "@/components/Pricing";
import Waitlist from "@/components/Waitlist";
import Footer from "@/components/Footer";

export default function Landing() {
  return (
    <div className="bg-black min-h-screen overflow-x-hidden">
      <Navbar />
      <Hero />
      <Problem />
      <WhatItIs />
      <Features />
      <BrandVideo />
      <RankSystem />
      <Pricing />
      <Waitlist />
      <Footer />
    </div>
  );
}
