import { useEffect, useRef, useState } from "react";
import heroVideo from "@assets/Cyberpunk_Logo_Reveal_ShiftGlitch_1775287889377.mp4";
import logoTagline from "@assets/SHIFTGLITCH_logo_grades_and_aura_fall_up_1775287889378.png";

const BOOT_LINES = [
  "> SHIFTGLITCH OS v18.0 — INITIALISING...",
  "> Neural pathway integrity: OPTIMAL",
  "> Spaced repetition engine: LOADED",
  "> Active recall protocols: ARMED",
  "> Forgetting curve: NEUTRALISED",
  "> Mainframe access: GRANTED",
  "> Welcome, Operative.",
];

export default function Hero() {
  const [bootLines, setBootLines] = useState<string[]>([]);
  const [videoReady, setVideoReady] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      if (i < BOOT_LINES.length) {
        setBootLines((prev) => [...prev, BOOT_LINES[i]]);
        i++;
      } else {
        clearInterval(interval);
      }
    }, 340);
    return () => clearInterval(interval);
  }, []);

  const scrollToWaitlist = () => {
    document.getElementById("waitlist")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-black">
      {/* Video background */}
      <div className="absolute inset-0 z-0">
        <video
          ref={videoRef}
          src={heroVideo}
          autoPlay
          muted
          loop
          playsInline
          onCanPlay={() => setVideoReady(true)}
          className={`w-full h-full object-cover transition-opacity duration-1000 ${videoReady ? "opacity-20" : "opacity-0"}`}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/80" />
      </div>

      {/* Scanlines overlay */}
      <div className="absolute inset-0 z-10 scanlines opacity-30 pointer-events-none" />

      {/* Grid overlay */}
      <div
        className="absolute inset-0 z-10 pointer-events-none opacity-10"
        style={{
          backgroundImage:
            "linear-gradient(rgba(57,255,20,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(57,255,20,0.3) 1px, transparent 1px)",
          backgroundSize: "80px 80px",
        }}
      />

      {/* Content */}
      <div className="relative z-20 max-w-5xl mx-auto px-4 sm:px-6 text-center pt-24">
        {/* Boot terminal */}
        <div className="terminal-border bg-black/80 p-4 mb-10 text-left max-w-xl mx-auto">
          {bootLines.map((line, i) => (
            <p key={i} className="font-mono-sg text-xs text-[#39FF14] leading-relaxed">
              {line}
            </p>
          ))}
          {bootLines.length < BOOT_LINES.length && (
            <span className="inline-block w-2 h-4 bg-[#39FF14] animate-pulse ml-1" />
          )}
        </div>

        {/* Logo with tagline */}
        <div className="flex justify-center mb-8">
          <img
            src={logoTagline}
            alt="ShiftGlitch — Grades and Aura Fall Up"
            className="w-full max-w-2xl"
          />
        </div>

        {/* Main headline */}
        <h1 className="font-display text-5xl sm:text-7xl lg:text-8xl text-white mb-4 leading-tight">
          THE STUDY APP BUILT ON THE
          <span className="text-[#39FF14] glow-green block">EVIDENCE.</span>
          <span className="text-white/30 text-3xl sm:text-4xl lg:text-5xl">NOT THE VIBE.</span>
        </h1>

        <p className="font-sans text-lg sm:text-xl text-white/70 max-w-2xl mx-auto mb-10 leading-relaxed">
          Spaced repetition. Active recall. Deliberate practice.{" "}
          <span className="text-[#39FF14]">The methods that cognitive science has proven actually work.</span>{" "}
          No passive rereading. No highlighting. No lies.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a
            href="https://shiftglitch.com"
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono-sg text-sm tracking-widest px-8 py-4 bg-[#39FF14] text-black font-bold hover:bg-white transition-colors uppercase pulse-green"
          >
            Jack In — It's Free
          </a>
          <button
            onClick={() => document.getElementById("the-problem")?.scrollIntoView({ behavior: "smooth" })}
            className="font-mono-sg text-sm tracking-widest px-8 py-4 border border-white/30 text-white/70 hover:border-[#FF00FF] hover:text-[#FF00FF] transition-colors uppercase"
          >
            Why It Matters
          </button>
        </div>

        {/* Stats bar */}
        <div className="mt-16 grid grid-cols-3 gap-4 border-t border-[#39FF14]/20 pt-8">
          {[
            ["18", "Development Phases"],
            ["5", "Rank Tiers"],
            ["10", "Cognitive Modules"],
          ].map(([num, label]) => (
            <div key={label} className="text-center">
              <div className="font-display text-4xl sm:text-5xl text-[#39FF14] glow-green">{num}</div>
              <div className="font-mono-sg text-xs text-white/40 tracking-widest uppercase mt-1">{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 animate-bounce">
        <div className="font-mono-sg text-xs text-[#39FF14]/60 tracking-widest">SCROLL DOWN</div>
        <div className="w-px h-8 bg-gradient-to-b from-[#39FF14]/60 to-transparent" />
      </div>
    </section>
  );
}
