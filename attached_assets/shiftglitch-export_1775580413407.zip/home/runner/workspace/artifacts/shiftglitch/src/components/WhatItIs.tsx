export default function WhatItIs() {
  return (
    <section className="py-24 sm:py-32 bg-[#030303] relative overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none opacity-5"
        style={{
          backgroundImage: "radial-gradient(circle at 50% 50%, #39FF14 0%, transparent 70%)",
        }}
      />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="sector-label mb-4">// SYSTEM IDENTIFICATION</div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="font-display text-5xl sm:text-6xl text-white mb-6 leading-tight">
              NOT AN APP.
              <span className="text-[#39FF14] glow-green block">AN OPERATING SYSTEM</span>
              FOR HOW YOU STUDY.
            </h2>

            <p className="text-white/70 leading-relaxed mb-6">
              ShiftGlitch is not a flashcard app, not a timer, not a quiz game, and not a note-taking tool — though it includes all of those things.
            </p>
            <p className="text-white/70 leading-relaxed mb-8">
              It is a single platform that teaches, implements, and tracks the most effective learning techniques known to science. At its core, ShiftGlitch does three things:
            </p>

            <div className="space-y-4">
              {[
                { num: "01", text: "It teaches you what the best study methods are and WHY they work." },
                { num: "02", text: "It gives you hands-on tools that implement those methods directly." },
                { num: "03", text: "It tracks your use over time, translating consistent effort into tangible progression." },
              ].map(({ num, text }) => (
                <div key={num} className="flex items-start gap-4 terminal-border p-4 bg-black">
                  <span className="font-display text-3xl text-[#39FF14] shrink-0">{num}</span>
                  <p className="text-white/80 text-sm leading-relaxed pt-1">{text}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="terminal-border-magenta p-6 bg-black">
              <div className="font-mono-sg text-xs text-[#FF00FF] tracking-widest mb-3">// WHAT SHIFTGLITCH IS NOT</div>
              <ul className="space-y-2">
                {[
                  "Not a quiz game (Quizlet, Kahoot, Blooket)",
                  "Not a gamified distraction (Duolingo)",
                  "Not a homework tracker (ManageBac, Firefly)",
                  "Not a flashcard app with a leaderboard bolted on",
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2 text-sm text-white/50">
                    <span className="text-[#FF00FF] shrink-0">✗</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="terminal-border p-6 bg-black">
              <div className="font-mono-sg text-xs text-[#39FF14] tracking-widest mb-3">// WHAT SHIFTGLITCH IS</div>
              <ul className="space-y-2">
                {[
                  "A full study methods OS for teenagers",
                  "Built on peer-reviewed cognitive science",
                  "Implements spaced repetition + active recall",
                  "5-rank progression earned by behaviour, not purchases",
                  "Evidence-based — not opinion, not intuition",
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2 text-sm text-white/80">
                    <span className="text-[#39FF14] shrink-0">✓</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-[#39FF14]/5 border border-[#39FF14]/20 p-4">
              <p className="font-mono-sg text-xs text-[#39FF14] tracking-widest">
                &gt; "The study app that looks like it belongs in a hacking movie is not competing on generic flashcard features. It is competing on philosophy, on honesty, and on the quality of the experience it creates."
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
