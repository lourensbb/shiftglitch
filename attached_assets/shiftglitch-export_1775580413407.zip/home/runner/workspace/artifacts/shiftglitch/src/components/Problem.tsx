export default function Problem() {
  return (
    <section id="the-problem" className="py-24 sm:py-32 bg-black relative overflow-hidden">
      {/* Background accent */}
      <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#FF00FF]" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="sector-label mb-4">// SYSTEM ALERT — MEMORY DEGRADATION DETECTED</div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          <div>
            <h2 className="font-display text-5xl sm:text-6xl text-white mb-6 leading-tight">
              YOU'VE BEEN
              <span className="text-[#FF00FF] glow-magenta block">STUDYING WRONG</span>
              YOUR ENTIRE LIFE.
            </h2>
            <p className="text-white/70 leading-relaxed mb-6">
              Every year, millions of teenagers sit down to study and do exactly the same thing: they open their notes, read them through, and close them again. They highlight passages in fluorescent colours. They reread the same pages the night before an exam.
            </p>
            <p className="text-white/70 leading-relaxed mb-6">
              It does not work. The research on this is not ambiguous.
            </p>
            <p className="text-[#39FF14] font-mono-sg text-sm leading-relaxed terminal-border p-4 bg-[#39FF14]/5">
              &gt; Hermann Ebbinghaus, 1885: humans forget roughly 70% of new information within 24 hours without active reinforcement. 140 years of cognitive science has refined that finding — but never overturned it.
            </p>
          </div>

          <div className="space-y-6">
            {[
              {
                stat: "70%",
                color: "#FF00FF",
                label: "FORGOTTEN IN 24 HOURS",
                desc: "Without active reinforcement, most new memories are gone within a day. This is the Forgetting Curve — and rereading does nothing to stop it.",
              },
              {
                stat: "50%",
                color: "#39FF14",
                label: "MORE RETAINED WITH TESTING",
                desc: "Roediger & Karpicke (2006): students who tested themselves retained 50% more information after one week than students who reread the same material twice.",
              },
              {
                stat: "0",
                color: "#FF8800",
                label: "SCHOOLS TEACHING THIS",
                desc: "Teenagers are failing not because they are lazy — but because nobody has ever taught them how to study. They are working hard at the wrong things.",
              },
            ].map(({ stat, color, label, desc }) => (
              <div key={label} className="border border-white/10 p-5 bg-white/[0.02] hover:bg-white/[0.04] transition-colors">
                <div className="flex items-start gap-4">
                  <div className="font-display text-4xl shrink-0" style={{ color }}>
                    {stat}
                  </div>
                  <div>
                    <div className="font-mono-sg text-xs tracking-widest mb-1" style={{ color }}>
                      {label}
                    </div>
                    <p className="text-white/60 text-sm leading-relaxed">{desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 border border-[#FF00FF]/30 p-8 bg-[#FF00FF]/5 text-center">
          <p className="font-display text-3xl sm:text-4xl text-white">
            The tragedy is that teenagers are not failing because they are lazy or uncommitted.
          </p>
          <p className="font-display text-3xl sm:text-4xl text-[#FF00FF] mt-2">
            They are failing because nobody has ever taught them how to study.
          </p>
          <p className="font-mono-sg text-sm text-white/40 mt-4 tracking-widest">ShiftGlitch exists to solve that problem.</p>
        </div>
      </div>
    </section>
  );
}
