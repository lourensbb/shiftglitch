const PLANS = [
  {
    name: "FREE",
    codename: "NPC TIER",
    price: "R0",
    period: "forever",
    color: "#ffffff",
    highlight: false,
    features: [
      "Unlimited flashcard decks",
      "Full Learning Governor (Pomodoro)",
      "Blurting Method — BrainDump sessions",
      "MCQ Diagnostic Boss Fights (100 questions)",
      "Babel Fish Metaphor Lab",
      "Eisenhower Matrix + Dopamine Recalibrator",
      "Full 5-rank progression system",
      "System INTERRUPT engine + The Warden",
      "Repeatable Escape Run system",
      "Memory Palace + Mind Map + Chunking Engine",
      "Leaderboard (global rankings)",
    ],
    cta: "Start Free — No Card Required",
    ctaAction: "waitlist",
    note: "The free tier is genuinely useful. Always.",
  },
  {
    name: "NETRUNNER PRO",
    codename: "PRO TIER",
    price: "R99",
    period: "/ month",
    altPrice: "R799 / year",
    color: "#39FF14",
    highlight: true,
    features: [
      "Everything in Free",
      "AI Mission Architect (study plan generator)",
      "Squad Mode — co-op groups up to 4",
      "Advanced Cognitive Exploit Modules",
      "Mistake Vault + Teach It + Dual Coding Station",
      "The Interleave + Concept Mapper + Shadow Protocol",
      "Firebase cloud sync (multi-device)",
      "Priority Warden transmissions",
      "Operative Status Board — full analytics",
    ],
    cta: "Go Pro — R99/month",
    ctaAction: "waitlist",
    note: "≈ R26/week. Less than one energy drink per session.",
  },
  {
    name: "SCHOOL LICENSE",
    codename: "INSTITUTION TIER",
    price: "R499",
    period: "/ year",
    color: "#FF00FF",
    highlight: false,
    features: [
      "Everything in Pro for all enrolled students",
      "Teacher Dashboard — class-wide analytics",
      "Rank distribution + activity levels per student",
      "Students needing attention — flagged automatically",
      "Printable individual progress reports",
      "No student accounts needed on teacher side",
      "JSON export system — one file per student",
      "Institution-wide Squad Mode",
      "Dedicated support channel",
    ],
    cta: "Get School Access",
    ctaAction: "waitlist",
    note: "Heads of department can often approve this without committee.",
  },
];

export default function Pricing() {
  const scrollToWaitlist = () => {
    document.getElementById("waitlist")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="pricing" className="py-24 sm:py-32 bg-[#030303] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="sector-label mb-4">// ACCESS TIER SELECTION</div>

        <div className="mb-16 text-center">
          <h2 className="font-display text-5xl sm:text-6xl text-white mb-4 leading-tight">
            FREE IS GENUINELY FREE.
            <span className="text-[#39FF14] glow-green block">PRO IS WORTH IT.</span>
          </h2>
          <p className="text-white/60 font-mono-sg text-sm max-w-xl mx-auto">
            Progression is earned, not purchased. No rank can be bought. Monetisation never affects learning outcomes.
          </p>
          <div className="mt-4 inline-block bg-[#FF00FF]/10 border border-[#FF00FF]/30 px-4 py-2">
            <span className="font-mono-sg text-xs text-[#FF00FF] tracking-widest">PAYFAST ZAR PAYMENTS — NO STRIPE</span>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {PLANS.map((plan) => (
            <div
              key={plan.name}
              className={`border p-6 flex flex-col relative ${
                plan.highlight
                  ? "border-[#39FF14] bg-[#39FF14]/5"
                  : "border-white/10 bg-white/[0.02]"
              }`}
            >
              {plan.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#39FF14] text-black font-mono-sg text-xs px-3 py-1 tracking-widest">
                  MOST POPULAR
                </div>
              )}

              <div className="font-mono-sg text-xs tracking-widest mb-1" style={{ color: plan.color }}>
                {plan.codename}
              </div>
              <div className="font-display text-3xl text-white mb-4">{plan.name}</div>

              <div className="mb-2">
                <span className="font-display text-5xl" style={{ color: plan.color }}>{plan.price}</span>
                <span className="font-mono-sg text-sm text-white/40 ml-2">{plan.period}</span>
              </div>
              {plan.altPrice && (
                <div className="font-mono-sg text-xs text-white/30 mb-6">
                  or {plan.altPrice} (save 33%)
                </div>
              )}
              {!plan.altPrice && <div className="mb-6" />}

              <ul className="space-y-2 mb-8 flex-1">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-xs text-white/70">
                    <span style={{ color: plan.color }} className="shrink-0 mt-0.5">✓</span>
                    {f}
                  </li>
                ))}
              </ul>

              <a
                href="https://shiftglitch.com"
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono-sg text-xs tracking-widest py-3 px-4 transition-all uppercase w-full text-center block"
                style={{
                  backgroundColor: plan.highlight ? "#39FF14" : "transparent",
                  color: plan.highlight ? "#000" : plan.color,
                  border: `1px solid ${plan.color}`,
                }}
              >
                {plan.cta}
              </a>
              <p className="font-mono-sg text-xs text-white/30 mt-3 text-center">{plan.note}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 terminal-border p-6 bg-black/50 text-center">
          <p className="font-mono-sg text-xs text-[#39FF14] tracking-widest mb-2">// PRICING PRINCIPLE</p>
          <p className="text-white/70 text-sm">
            "Progression is permanent and irreversible. It cannot be bought, skipped, or hacked. The only path forward is demonstrated behaviour."
          </p>
          <p className="font-mono-sg text-xs text-white/30 mt-2">Paying for Pro gives you more tools. It does not make you smarter. You have to do that part yourself.</p>
        </div>
      </div>
    </section>
  );
}
