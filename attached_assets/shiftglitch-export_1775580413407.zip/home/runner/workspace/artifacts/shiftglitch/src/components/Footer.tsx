import logoImg from "@assets/SHIFTGLITCH_logo_1775287889378.png";

export default function Footer() {
  return (
    <footer className="border-t border-[#39FF14]/20 bg-black py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid sm:grid-cols-3 gap-8 mb-8">
          <div>
            <img src={logoImg} alt="ShiftGlitch" className="h-10 w-auto mb-3" />
            <p className="font-mono-sg text-xs text-white/40 leading-relaxed">
              A cyberpunk study-methods OS.<br />
              Built on cognitive science.<br />
              Not on the vibe.
            </p>
          </div>

          <div>
            <div className="font-mono-sg text-xs text-[#39FF14] tracking-widest mb-3">// QUICK ACCESS</div>
            <ul className="space-y-2">
              {[
                ["the-problem", "The Problem"],
                ["features", "Tools"],
                ["ranks", "Rank System"],
                ["pricing", "Pricing"],
                ["waitlist", "Enter the Mainframe"],
              ].map(([id, label]) => (
                <li key={id}>
                  <button
                    onClick={() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })}
                    className="font-mono-sg text-xs text-white/40 hover:text-[#39FF14] transition-colors"
                  >
                    {label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <div className="font-mono-sg text-xs text-[#39FF14] tracking-widest mb-3">// SYSTEM ARCHITECTURE</div>
            <ul className="space-y-2">
              {[
                "Spaced Repetition — Leitner System",
                "Active Recall — Testing Effect",
                "Pomodoro — Deliberate Practice",
                "Feynman — Explanation as Understanding",
                "Metacognition — Reflective Learning",
              ].map((item) => (
                <li key={item} className="font-mono-sg text-xs text-white/30">
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-mono-sg text-xs text-white/30">
            © 2026 ShiftGlitch. All rights reserved. A product by Lourens Breytenbach.
          </p>
          <div className="flex items-center gap-4">
            <a href="https://lourens.io" className="font-mono-sg text-xs text-white/30 hover:text-[#39FF14] transition-colors">
              lourens.io
            </a>
            <span className="text-white/20">·</span>
            <a href="mailto:hello@shiftglitch.com" className="font-mono-sg text-xs text-white/30 hover:text-[#39FF14] transition-colors">
              hello@shiftglitch.com
            </a>
          </div>
        </div>

        <div className="mt-6 text-center">
          <p className="font-mono-sg text-xs text-white/10 tracking-widest">
            SHIFTGLITCH OS v18.0 — MAINFRAME SECURE — ALL EVIDENCE REAL — NO VIBE
          </p>
        </div>
      </div>
    </footer>
  );
}
