export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-black">
      <div className="text-center">
        <div className="font-display text-[10rem] text-[#39FF14] leading-none" style={{ textShadow: "0 0 20px #39FF14" }}>
          404
        </div>
        <div className="font-mono-sg text-sm text-[#FF00FF] tracking-widest mb-4">
          PAGE NOT FOUND — MAINFRAME REJECTED YOUR REQUEST
        </div>
        <a
          href="/"
          className="inline-block font-mono-sg text-xs tracking-widest px-6 py-3 border border-[#39FF14] text-[#39FF14] hover:bg-[#39FF14] hover:text-black transition-colors uppercase"
        >
          Return to Base
        </a>
      </div>
    </div>
  );
}
